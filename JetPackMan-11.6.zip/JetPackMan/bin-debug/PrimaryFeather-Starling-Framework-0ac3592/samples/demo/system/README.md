Add this folder as a source path to your project. 
That way, the graphics will be added to the application package - which is needed so that iOS & Android pick them up.

Launch images:

  * Default-Portrait.png -> iPad
  * Default.png -> iPhone
  * Default.png -> iPhone Retina

Icons:

  * icon57.png -> iPhone
  * icon72.png -> iPad
  * icon114.png -> iPhone Retina
  * icon144.png -> iPad Retina

AIR Startup images: (displayed when AIR is ready, but Starling is still loading)

  * startup.jpg -> iPhone
  * startupHD.jpg -> iPhone Retina, iPad
