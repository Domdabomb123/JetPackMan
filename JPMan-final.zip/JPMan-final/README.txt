Project: Jet Pack Man
Date: 12-18-13
Members:
Daniel Quinnell
Dominic Schumerth
Brianna Peterson
Lucas Paul

To play game:
bin-debug > JetPackMan.swf
OR
bin-debug > JetPackMan.html

Note: When importing in Flash Builder, set Build Path to path>Starling...> src folder and path folder

